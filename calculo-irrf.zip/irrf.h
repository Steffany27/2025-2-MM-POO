#ifndef IRRF_H
#define IRRF_H

double calcularIrrf(double salarioBase);

#endif