#ifndef INSS_H
#define INSS_H

double calcularInss(double salarioBruto);

#endif