# Projeto Cálculo IRRF em C

Este projeto calcula INSS, salário base e IRRF.

## Compilar:

gcc main.c inss.c irrf.c -o calculo

## Executar:

./calculo
